# SSOT v7.4 Release Candidate (FINAL3_POSIX) — distribution bundle

Status: Canonical audit bundle (Phase1)
This artifact is hash-anchored and may contain legacy components for traceability.
See trace/attachments/errata.md for correction history.
この配布物は **2つのZIP** から構成されます。

- `release_candidate_FINAL3_POSIX.zip`（配布対象：規範入力 + how）
- `trace_evidence_FINAL3_POSIX.zip`（監査証拠：監査結果 + 追跡情報）

重要（運用ルール）:
- **release だけ更新は禁止**。改変するなら **trace を再生成してセット更新**してください。
- trace は release 本体に同梱しません（混線回避）。

---

## Legal / Usage (IMPORTANT)

**禁止（禁止事項）**
- 他人による **利用・改変・再配布** を禁止します。

**許可（それ以外）**
- 閲覧、読解、個人学習、監査・レビュー目的での参照（引用は最小限）。

**免責（READMEは情報提供のみ）**
- 本READMEおよび同梱文書は情報提供のみであり、法的助言ではありません。
- 本成果物は **現状有姿（AS IS）** で提供され、明示・黙示を問わず一切の保証をしません。
- 本成果物の利用または利用不能により生じたいかなる損害についても、作者は責任を負いません。

詳細な利用条件は `release_candidate_FINAL3_POSIX.zip` 内の `LICENSE` を参照してください。

## 1) ファイルとSHA256


> 注: trace.zip の SHA256 を README 内に固定値で埋め込むと、trace 側が README の sha を参照（outer_sums.json）しているため固定点になり得ます。従って trace.zip の SHA は README では断定せず、必要なら外部で算出してください。

- release: `release_candidate_FINAL3_POSIX.zip`
  - SHA256: `6b483f4a47fa28d55e01c38f02de010e039a8da5044d4a5ca45204f6f82e615a`
- trace: `trace_evidence_FINAL3_POSIX.zip`
  - SHA256: `(compute externally; see trace/outer_sums.json)`

---

## 2) 期待される内部パス（最低限）

### release 内（必須）
- `ssot/ssot_v7_4.yaml`
- `how/ledger.json`
- `how/how.schema.json`

### trace 内（必須）
- `manifest_prev.json`
- `manifest_next.json`
- `decisions.jsonl`
- `diff_paths.json`
- `audit_report.json`
- `audit_declaration.md`

---

## 3) “一発” 検証（PowerShell / 初期位置から）

前提:
- 2つのZIPが同じフォルダにある（例: `Downloads`）。
- PowerShell をどこから起動しても良い（初期位置のままOK）。

### 3.1 最小ワンショット（構造＋必須ファイルの存在＋ZIPのSHA256表示）
下を **そのまま** PowerShell に貼り付けてください（`$dir` だけ必要なら変更）。

```powershell
# ===== EDIT ONLY HERE (where the two zips are) =====
$dir = "$HOME\Downloads"

$releaseZip = Join-Path $dir "release_candidate_FINAL3_POSIX.zip"
$traceZip   = Join-Path $dir "trace_evidence_FINAL3_POSIX.zip"

# ===== precheck =====
if (!(Test-Path $releaseZip)) { throw "STOP: missing $releaseZip" }
if (!(Test-Path $traceZip))   { throw "STOP: missing $traceZip" }

# ===== temp workdir =====
$w = Join-Path $env:TEMP ("ssot_verify_" + [guid]::NewGuid().ToString("N"))
$wRel = Join-Path $w "release"
$wTr  = Join-Path $w "trace"
New-Item -ItemType Directory -Force -Path $wRel,$wTr | Out-Null

Expand-Archive -Force -LiteralPath $releaseZip -DestinationPath $wRel
Expand-Archive -Force -LiteralPath $traceZip   -DestinationPath $wTr

# ===== required checks =====
$req = @(
  @{Type="release"; Logical="ssot/ssot_v7_4.yaml";  Path=(Join-Path $wRel "ssot\ssot_v7_4.yaml")},
  @{Type="release"; Logical="how/ledger.json";      Path=(Join-Path $wRel "how\ledger.json")},
  @{Type="release"; Logical="how/how.schema.json";  Path=(Join-Path $wRel "how\how.schema.json")},
  @{Type="trace";   Logical="manifest_prev.json";   Path=(Join-Path $wTr  "manifest_prev.json")},
  @{Type="trace";   Logical="manifest_next.json";   Path=(Join-Path $wTr  "manifest_next.json")},
  @{Type="trace";   Logical="decisions.jsonl";      Path=(Join-Path $wTr  "decisions.jsonl")},
  @{Type="trace";   Logical="diff_paths.json";      Path=(Join-Path $wTr  "diff_paths.json")},
  @{Type="trace";   Logical="audit_report.json";    Path=(Join-Path $wTr  "audit_report.json")},
  @{Type="trace";   Logical="audit_declaration.md"; Path=(Join-Path $wTr  "audit_declaration.md")}
)

"== REQUIRED FILES CHECK =="
$req | ForEach-Object {
  [PSCustomObject]@{
    Type    = $_.Type
    Logical = $_.Logical
    Found   = (Test-Path $_.Path)
    Path    = $_.Path
  }
} | Format-Table -AutoSize

$missing = @($req | Where-Object { -not (Test-Path $_.Path) })
if ($missing.Count -gt 0) {
  throw "STOP: missing required files (see table above)."
}

"== INPUT ZIP SHA256 =="
Get-FileHash -Algorithm SHA256 -LiteralPath $releaseZip,$traceZip |
  Format-Table Algorithm,Hash,Path -AutoSize

"== OK =="
"Workdir: $w"
```

### 3.2 追加（任意）: how.schema で how/ledger をJSON Schema検証
PowerShellだけでJSON Schema検証を完結させるのは面倒なので、**Node.js** が入っている環境なら以下が単純です。

1) 上の出力 `Workdir` の `release` に移動:
```powershell
cd (Join-Path $w 'release')
```

2) `ajv-cli` で検証:
```powershell
npm -g i ajv-cli
ajv validate -s .\how\how.schema.json -d .\how\ledger.json
```

---

## 4) よくある失敗
- ZIPをどこかに移動したのに `$dir` を変えていない
- `trace` だけ新しくして `release` を古いまま（セット更新ルール違反）
- 展開先のパスが長すぎてWindowsが詰まる → `$env:TEMP` を短い場所に変える

---

## 5) このREADMEの生成日
- 2026-01-21
## vNext Phase1
This bundle includes Phase1 internal-consistency artifacts for release/trace packaging. Phase1 asserts internal consistency and outer mix-up detection for release/ps1/README only; it does not authenticate origin and makes no claim about any external expected match.

---

## 3) 変更履歴（trace内に埋め込み）

本配布物の「誤記→訂正」や追加変更は、trace 内の `attachments/errata.md` に記録します。

- 位置: `trace_evidence_FINAL3_POSIX.zip` 内 `attachments/errata.md`
- 固定化: `attachments_manifest.json` → `binding.json` のハッシュ連鎖により、後から差し替えられていないことを検証できます

---

## 4) GitHub 公開向けの最低限品質（v7_tools）

release 内の `v7_tools/` は、CI とローカル実行（Makefile）で「動くこと」を確認するための最小ツール群です。
詳細は release 内の `docs/definition_of_done.md` と `docs/github_publish_checklist.md` を参照してください。
