# ===== EDIT ONLY HERE (where the two zips are) =====
$dir = "$HOME\Downloads"

$releaseZip = Join-Path $dir "release_candidate_FINAL3_POSIX.zip"
$traceZip   = Join-Path $dir "trace_evidence_FINAL3_POSIX.zip"

# ===== precheck =====
if (!(Test-Path $releaseZip)) { throw "STOP: missing $releaseZip" }
if (!(Test-Path $traceZip))   { throw "STOP: missing $traceZip" }

# ===== temp workdir =====
$w = Join-Path $env:TEMP ("ssot_verify_" + [guid]::NewGuid().ToString("N"))
$wRel = Join-Path $w "release"
$wTr  = Join-Path $w "trace"
New-Item -ItemType Directory -Force -Path $wRel,$wTr | Out-Null

Expand-Archive -Force -LiteralPath $releaseZip -DestinationPath $wRel
Expand-Archive -Force -LiteralPath $traceZip   -DestinationPath $wTr

# ===== required checks =====
$req = @(
  @{Type="release"; Logical="ssot/ssot_v7_4.yaml";  Path=(Join-Path $wRel "ssot\ssot_v7_4.yaml")},
  @{Type="release"; Logical="how/ledger.json";      Path=(Join-Path $wRel "how\ledger.json")},
  @{Type="release"; Logical="how/how.schema.json";  Path=(Join-Path $wRel "how\how.schema.json")},
  @{Type="trace";   Logical="manifest_prev.json";   Path=(Join-Path $wTr  "manifest_prev.json")},
  @{Type="trace";   Logical="manifest_next.json";   Path=(Join-Path $wTr  "manifest_next.json")},
  @{Type="trace";   Logical="decisions.jsonl";      Path=(Join-Path $wTr  "decisions.jsonl")},
  @{Type="trace";   Logical="diff_paths.json";      Path=(Join-Path $wTr  "diff_paths.json")},
  @{Type="trace";   Logical="audit_report.json";    Path=(Join-Path $wTr  "audit_report.json")},
  @{Type="trace";   Logical="audit_declaration.md"; Path=(Join-Path $wTr  "audit_declaration.md")}
)

"== REQUIRED FILES CHECK =="
$req | ForEach-Object {
  [PSCustomObject]@{
    Type    = $_.Type
    Logical = $_.Logical
    Found   = (Test-Path $_.Path)
    Path    = $_.Path
  }
} | Format-Table -AutoSize

$missing = @($req | Where-Object { -not (Test-Path $_.Path) })
if ($missing.Count -gt 0) {
  throw "STOP: missing required files (see table above)."
}

"== INPUT ZIP SHA256 =="
Get-FileHash -Algorithm SHA256 -LiteralPath $releaseZip,$traceZip |
  Format-Table Algorithm,Hash,Path -AutoSize

"== OK =="
"Workdir: $w"
